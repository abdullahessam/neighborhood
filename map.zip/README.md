**for auto complete i used jquery ui** \
https://jqueryui.com/autocomplete 
**3rd party api**
i used NYT articles api
